import {Component, OnInit} from '@angular/core';
import {CategoryService} from "./services/category.service";
import {IngredientService} from "./services/ingredient.service";
import {RecipeService} from "./services/recipe.service";
import {Category} from "./model/Category";
import {Recipe} from "./model/Recipe";
import {Ingredient} from "./model/Ingredient";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit{

  constructor(private categoryService: CategoryService, private ingredientService: IngredientService, private recipeService: RecipeService){
  }

  requrencyIngredientDelete(recipe: Recipe, ingredient: Ingredient){
    let mode = false;
    let index = recipe.ingredients.indexOf(ingredient);
    if(index !== -1){
      recipe.ingredients.splice(index, 1);
      recipe.ingredientValues.splice(index, 1);
      mode = true;
    }
    if(mode){
      this.requrencyIngredientDelete(recipe, ingredient);
    }
  }

  ngOnInit(){
    this.categoryService.generateCategory();
    this.categoryService.generateEmitter.subscribe(
      (categories: Category[]) => {
        this.ingredientService.generateIngredients();
        this.ingredientService.generateEmitter.subscribe(
          (ingredients: Ingredient[]) => {
            this.recipeService.generateRecipes();
          }
        )
      }
    );

    this.categoryService.deleteEmitter.subscribe(
      (category: Category) => {
        let recipes: Recipe[] = this.recipeService.getRecipes();
        for(let i = 0 ; i < recipes.length; i++){
          if(recipes[i].categories != null) {
            let index: number = -1;
            index = recipes[i].categories.indexOf(category);
            if (index !== -1) {
              recipes[i].categories.splice(index, 1);
            }
          }
        }
      }
    );

    this.ingredientService.deleteEmitter.subscribe(
      (ingredient: Ingredient) => {
        let recipes: Recipe[] = this.recipeService.getRecipes();
        for(let i = 0 ; i < recipes.length; i++){
          if(recipes[i].ingredients != null) {
            this.requrencyIngredientDelete(recipes[i], ingredient);
          }
        }
      }
    );

  }

}


