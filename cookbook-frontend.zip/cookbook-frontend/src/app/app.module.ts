import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { CategoryListComponent } from './components/category/category-list.component';
import {routing} from "./app.routing";
import { CategoryItemComponent } from './components/category/category-item.component';
import {CategoryService} from "./services/category.service";
import { FilterPipe } from './pipes/filter.pipe';
import { IngredientListComponent } from './components/ingredient/ingredient-list.component';
import { IngredientItemComponent } from './components/ingredient/ingredient-item.component';
import {IngredientService} from "./services/ingredient.service";
import {RlTagInputModule} from 'angular2-tag-input';
import { RecipeListComponent } from './components/recipe/recipe-list.component';
import {RecipeService} from "./services/recipe.service";
import { RecipeItemComponent } from './components/recipe/recipe-item.component';
import { RecipeViewComponent } from './components/recipe/recipe-view.component';
import { RecipeAddComponent } from './components/recipe/recipe-add.component';
import { RecipeEditComponent } from './components/recipe/recipe-edit.component';
import { DatepickerModule } from 'angular2-material-datepicker';
import { RecipePipe } from './pipes/recipe.pipe';
import { RecipeInComponent } from './components/recipe/recipe-in.component';
import { LoaderComponent } from './components/utils/loader.component';
import { TinyComponent } from './components/utils/tiny.component';

@NgModule({
  declarations: [
    AppComponent,
    CategoryListComponent,
    CategoryItemComponent,
    FilterPipe,
    IngredientListComponent,
    IngredientItemComponent,
    RecipeListComponent,
    RecipeItemComponent,
    RecipeViewComponent,
    RecipeAddComponent,
    RecipeEditComponent,
    RecipePipe,
    RecipeInComponent,
    LoaderComponent,
    TinyComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing,
    ReactiveFormsModule,
    RlTagInputModule,
    DatepickerModule
  ],
  providers: [CategoryService, IngredientService, RecipeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
