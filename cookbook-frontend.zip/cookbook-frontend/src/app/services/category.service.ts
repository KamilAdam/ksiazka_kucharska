import {Injectable, OnInit, EventEmitter} from '@angular/core';
import {Category} from "../model/Category";
import {RecipeService} from "./recipe.service";
import {Http, Headers, Response} from "@angular/http";
import {Observable} from "rxjs/Rx";

@Injectable()
export class CategoryService {

  public categoryList: Category[] = [];
  public deleteEmitter = new EventEmitter<Category>();
  public generateEmitter = new EventEmitter<Category[]>();
  public updateEmitter = new EventEmitter<Category>();
  public addEmitter = new EventEmitter<Category>();

  constructor(private http: Http) { }

  getCategoriesCount(){
    return this.categoryList.length;
  }

  generateCategory(){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.get("http://localhost:8080/category", {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          for(let i = 0; i < data.length; i++){
            this.categoryList.push( new Category(+data[i].id, data[i].name) );
          }
          this.generateEmitter.emit(this.categoryList);
        }
      );
  }

  getCategories(){
    return this.categoryList;
  }

  getCategoryById(id: number){
    for(let i = 0; i < this.categoryList.length; i++){
      if( this.categoryList[i].id == id ){
        return this.categoryList[i];
      }
    }
    return null;
  }

  getCategoryByIndex(index: number){
    if( this.categoryList.length > index ){
      return this.categoryList[index];
    }
    return null;
  }

  getCategoriesByIndex(index: number[]){
    let categories: Category[] = [];
    for(let i = 0; i < this.categoryList.length; i++){
      if( index.indexOf(this.categoryList[i].id) !== -1){
        categories.push(this.categoryList[i]);
      }
    }
    return categories;
  }

  deleteCategory(category: Category){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.delete("http://localhost:8080/category/delete/" + category.id, {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          if(data){
            var index = this.categoryList.indexOf(category);
            if( index === -1){
              return;
            }
            this.deleteEmitter.emit(category);
            this.categoryList.splice(index, 1);
          }else{
            console.log("nie mogłem usunąć kategorii, category.service.ts - deleteCategory()");
          }
        }
      );
  }

  freeCategory(name: string) : boolean{
    for(let i = 0; i < this.categoryList.length; i++){
      if( this.categoryList[i].name.toUpperCase() == name.toUpperCase() ){
        return false;
      }
    }
    return true;
  }

  freeCategoryExcerpt(name: string, ex: string) : boolean{
    for(let i = 0; i < this.categoryList.length; i++){
      if( this.categoryList[i].name.toUpperCase() == name.toUpperCase() && this.categoryList[i].name.toUpperCase() != ex.toUpperCase() ){
        return false;
      }
    }
    return true;
  }

  updateCategory(category: Category, name: string){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    category.name = name;
    this.http.put("http://localhost:8080/category/update/", JSON.stringify(category), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          if(data){
            for(let i = 0; i < this.categoryList.length; i++){
              if( this.categoryList[i].id == category.id ){
                this.categoryList[i].name = name;
                break;
              }
            }
            this.updateEmitter.emit(category);
          }else{
            console.log("nie mogłem zaktualizować kategorii, category.service.ts - updateCategory()");
          }
        }
      );
  }

  addCategory(name: string){
    let category: Category = new Category(0, name);
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.post("http://localhost:8080/category/add/", JSON.stringify(category), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          category.id = +data;
          this.categoryList.push(category);
          this.addEmitter.emit(this.categoryList[this.categoryList.length-1]);
        }
      );
  }

  private handleError (error: any) {
    console.log(error);
    return Observable.throw(error.json());
  }

}
