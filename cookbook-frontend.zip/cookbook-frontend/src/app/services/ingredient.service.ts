import {Injectable, EventEmitter} from '@angular/core';
import {Ingredient} from "../model/Ingredient";
import {Http, Headers, Response} from "@angular/http";
import {Observable} from "rxjs/Rx";

@Injectable()
export class IngredientService {

  public ingredientList: Ingredient[] = [];
  public deleteEmitter = new EventEmitter<Ingredient>();
  public generateEmitter = new EventEmitter<Ingredient[]>();
  public updateEmitter = new EventEmitter<Ingredient>();
  public addEmitter = new EventEmitter<Ingredient>();

  constructor(private http: Http) { }

  getIngredientsCount(){
    return this.ingredientList.length;
  }

  generateIngredients(){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.get("http://localhost:8080/ingredient", {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          for(let i = 0; i < data.length; i++){
            this.ingredientList.push( new Ingredient(+data[i].id, data[i].name, data[i].units) );
          }
          this.generateEmitter.emit(this.ingredientList);
        }
      );
  }

  getIngredients(){
    return this.ingredientList;
  }

  getIngredientById(id: number){
    for(let i = 0; i < this.ingredientList.length; i++){
      if( this.ingredientList[i].id == id ){
        return this.ingredientList[i];
      }
    }
    return null;
  }

  getIngredientByIndex(index: number){
    if( this.ingredientList.length > index ){
      return this.ingredientList[index];
    }
    return null;
  }

  getIngredientsByIndex(index: number[]){
    let ingredients: Ingredient[] = [];
    for(let i = 0; i < this.ingredientList.length; i++){
      if( index.indexOf(this.ingredientList[i].id) !== -1){
        ingredients.push(this.ingredientList[i]);
      }
    }
    return ingredients;
  }

  deleteIngredient(ingredient: Ingredient){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.delete("http://localhost:8080/ingredient/delete/" + ingredient.id, {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          if(data){
            var index = this.ingredientList.indexOf(ingredient);
            if( index === -1){
              return;
            }
            this.deleteEmitter.emit(ingredient);
            this.ingredientList.splice(index, 1);
          }else{
            console.log("nie mogłem usunąć składnika, ingredients.service.ts - deleteIngrediens()");
          }
        }
      );
  }

  getIngredientUnit(ingredient: Ingredient){
    var index = this.ingredientList.indexOf(ingredient);
    if( index === -1 ){
      return [];
    }
    return this.ingredientList[index].units;
  }

  getIngredientUnitByName(name: string) : string[]{
    for(let i = 0; i < this.ingredientList.length; i++){
      if( this.ingredientList[i].name == name ){
        return this.ingredientList[i].units;
      }
    }
    return [];
  }

  getIngredientByName(name: string){
    for(let i = 0; i < this.ingredientList.length; i++){
      if( this.ingredientList[i].name == name ){
        return this.ingredientList[i];
      }
    }
    return null;
  }

  freeIngredient(name: string) : boolean{
    for(let i = 0; i < this.ingredientList.length; i++){
      if( this.ingredientList[i].name.toUpperCase() == name.toUpperCase() ){
        return false;
      }
    }
    return true;
  }

  freeIngredientExcerpt(name: string, ex: string) : boolean{
    for(let i = 0; i < this.ingredientList.length; i++){
      if( this.ingredientList[i].name.toUpperCase() == name.toUpperCase() && this.ingredientList[i].name.toUpperCase() != ex.toUpperCase() ){
        return false;
      }
    }
    return true;
  }

  updateIngredient(ingredient: Ingredient, name: string, units: string[]){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    ingredient.name = name;
    ingredient.units = units;
    this.http.put("http://localhost:8080/ingredient/update/", JSON.stringify(ingredient), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          if(data){
            for(let i = 0; i < this.ingredientList.length; i++){
              if( this.ingredientList[i].id == ingredient.id ){
                this.ingredientList[i].name = name;
                this.ingredientList[i].units = units;
                break;
              }
            }
            this.updateEmitter.emit(ingredient);
          }else{
            console.log("nie mogłem aktualizować składnika, ingredient.service.ts - updateIngredient()");
          }
        }
      );
  }

  addIngredient(name: string, units: string[]){
    let ingredient: Ingredient = new Ingredient(0, name, units);
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.post("http://localhost:8080/ingredient/add/", JSON.stringify(ingredient), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          ingredient.id = +data;
          this.ingredientList.push(ingredient);
          this.addEmitter.emit(this.ingredientList[this.ingredientList.length-1]);
        }
      );
  }

  private handleError (error: any) {
    console.log(error);
    return Observable.throw(error.json());
  }

}
