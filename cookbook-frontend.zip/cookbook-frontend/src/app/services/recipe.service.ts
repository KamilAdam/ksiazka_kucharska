import { Injectable, EventEmitter } from '@angular/core';
import {Recipe} from "../model/Recipe";
import {CategoryService} from "./category.service";
import {IngredientService} from "./ingredient.service";
import {WComment} from "../model/WComment";
import {Category} from "../model/Category";
import {Ingredient} from "../model/Ingredient";
import {Http, Headers, Response} from "@angular/http";
import {Observable} from "rxjs/Rx";
import {ActivatedRoute, Router} from "@angular/router";

@Injectable()
export class RecipeService {

  public recipeList: Recipe[] = [];

  public commentUpdate = new EventEmitter<Recipe>();
  public deleteLoad = new EventEmitter<Recipe>()
  public favouriteLoad = new EventEmitter<Recipe>();
  public generatedRecipes = new EventEmitter<Recipe[]>();

  constructor(private http:Http, private categoryService: CategoryService, private ingredientService: IngredientService, private router: Router) { }

  getRecipesCount(){
    return this.recipeList.length;
  }

  generateRecipes(){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.get("http://localhost:8080/", {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          let recipe: Recipe = null;
          for(let i = 0; i < data.length; i++){

            recipe = new Recipe(0, "", "", [], [], [], [], [], 0, 0, 0, 0, null, null, false);

            recipe.id = data[i].id;
            recipe.name = data[i].name;
            recipe.description = data[i].description;
            recipe.publishDate = new Date(data[i].publishDate);
            recipe.lastCookedDate = new Date(data[i].lastCookedDate);
            recipe.favorite = data[i].favorite;

            if( data[i].comments != null ){
              recipe.comments = data[i].comments;
            }

            if( data[i].categories != null ){
              if(data[i].categories.length > 0) {
                for (let j = 0; j < data[i].categories.length; j++) {
                  recipe.categories.push(this.categoryService.getCategoryById(+data[i].categories[j]));
                }
              }
            }

            if( data[i].ingredients != null ){
              if(data[i].ingredients.length > 0) {
                for (let j = 0; j < data[i].ingredients.length; j++) {
                  recipe.ingredients.push(this.ingredientService.getIngredientById(+data[i].ingredients[j]));
                }
                recipe.ingredientValues = data[i].ingredientValues;
              }
            }

            if( data[i].customIngredients != null ){
              recipe.customIngredients = data[i].customIngredients;
            }

            if( data[i].calories != null ){
              recipe.calories = data[i].calories;
            }

            if( data[i].costsServing != null ){
              recipe.costsServing = data[i].costsServing;
            }

            if( data[i].numberServing != null ){
              recipe.numberServing = data[i].numberServing;
            }

            if( data[i].prepareTime != null ){
              recipe.prepareTime = data[i].prepareTime;
            }

            this.recipeList.push(recipe);
            recipe = null;
          }
          this.generatedRecipes.emit(this.recipeList);
        }
      );
  }

  getRecipes(){
    return this.recipeList;
  }

  toggleFavourites(recipe: Recipe){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.put("http://localhost:8080/toggleFavorite/"+recipe.id+"/"+recipe.favorite, {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          if(recipe.favorite){
            recipe.favorite = false;
          }else{
            recipe.favorite = true;
          }
          this.favouriteLoad.emit(recipe);
        }
      );
  }

  getRecipeById(id: number){
    for(let i = 0; i < this.recipeList.length; i++){
      if( this.recipeList[i].id == id ){
        return this.recipeList[i];
      }
    }
    return null;
  }

  getRecipeByIndex(index: number){
    if( this.recipeList.length > index ){
      return this.recipeList[index];
    }
    return null;
  }

  getRecipesByCategory(category: Category, mode: boolean) : any{
    let count: number = 0;
    let recipes: Recipe[] = [];
    for(let recipe of this.recipeList){
      if( recipe.categories == null ) continue;
      if( recipe.categories.indexOf(category) !== -1 ){
        recipes.push(recipe);
        count++;
      }
    }
    return (mode) ? recipes : count;
  }

  getRecipesByIngredient(ingredient: Ingredient, mode:boolean) : any{
    let count: number = 0;
    let recipes: Recipe[] = [];
    for(let recipe of this.recipeList){
      if( recipe.ingredients.indexOf(ingredient) !== -1 ){
        recipes.push(recipe);
        count++;
      }
    }
    return (mode) ? recipes : count;
  }

  deleteRecipe(recipe: Recipe){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.delete("http://localhost:8080/delete/"+recipe.id, {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          var index = this.recipeList.indexOf(recipe);
          if( index === -1){
            return;
          }
          this.recipeList.splice(index, 1);
          this.deleteLoad.emit(recipe);
        }
      );
  }

  getRecipe(id: string){
    for(let i = 0; i < this.recipeList.length; i++){
      if( this.recipeList[i].id == (+id) ){
        return this.recipeList[i];
      }
    }
    return null;
  }

  addRecipe(recipe: Recipe){
    let preparedRecipe: any = {};
    let requestHeader = new Headers({'Content-Type': 'application/json'});

    preparedRecipe.id = recipe.id;
    preparedRecipe.name = recipe.name;
    preparedRecipe.description = recipe.description;
    preparedRecipe.categories = [];
    preparedRecipe.ingredients = [];
    preparedRecipe.ingredientValues = recipe.ingredientValues;
    preparedRecipe.customIngredients = recipe.customIngredients;
    preparedRecipe.comments = recipe.comments;
    preparedRecipe.prepareTime = recipe.prepareTime;
    preparedRecipe.costsServing = recipe.costsServing;
    preparedRecipe.calories = recipe.calories;
    preparedRecipe.numberServing = recipe.numberServing;
    preparedRecipe.publishDate = recipe.publishDate;
    preparedRecipe.lastCookedDate = recipe.lastCookedDate;
    preparedRecipe.favorite = recipe.favorite;

    for(let i = 0; i < recipe.categories.length; i++){
      preparedRecipe.categories.push(recipe.categories[i].id);
    }

    for(let i = 0; i < recipe.ingredients.length; i++){
      preparedRecipe.ingredients.push(recipe.ingredients[i].id);
    }

    this.http.post("http://localhost:8080/add/", JSON.stringify(preparedRecipe), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          recipe.id = +data;
          this.recipeList.push(recipe);
          this.router.navigate(['/przepisy']);
        }
      );

  }

  updateRecipe(oldRecipe: Recipe, newRecipe: Recipe){
    let preparedRecipe: any = {};
    let requestHeader = new Headers({'Content-Type': 'application/json'});

    preparedRecipe.id = newRecipe.id;
    preparedRecipe.name = newRecipe.name;
    preparedRecipe.description = newRecipe.description;
    preparedRecipe.categories = [];
    preparedRecipe.ingredients = [];
    preparedRecipe.ingredientValues = newRecipe.ingredientValues;
    preparedRecipe.customIngredients = newRecipe.customIngredients;
    preparedRecipe.comments = newRecipe.comments;
    preparedRecipe.prepareTime = newRecipe.prepareTime;
    preparedRecipe.costsServing = newRecipe.costsServing;
    preparedRecipe.calories = newRecipe.calories;
    preparedRecipe.numberServing = newRecipe.numberServing;
    preparedRecipe.publishDate = newRecipe.publishDate;
    preparedRecipe.lastCookedDate = newRecipe.lastCookedDate;
    preparedRecipe.favorite = newRecipe.favorite;

    for(let i = 0; i < newRecipe.categories.length; i++){
      preparedRecipe.categories.push(newRecipe.categories[i].id);
    }

    for(let i = 0; i < newRecipe.ingredients.length; i++){
      preparedRecipe.ingredients.push(newRecipe.ingredients[i].id);
    }

    this.http.put("http://localhost:8080/update/", JSON.stringify(preparedRecipe), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          var index = this.recipeList.indexOf(oldRecipe);
          if( index === -1){
            return;
          }
          this.recipeList[index] = null;
          this.recipeList[index] = newRecipe;
          this.router.navigate(['/przepisy']);
        }
      );
  }

  updateLastCookDate(cookDate: Date, recipe: Recipe){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.put("http://localhost:8080/updateLastCookDate/"+recipe.id+"/"+cookDate, {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          var index = this.recipeList.indexOf(recipe);
          if( index === -1){
            return;
          }
          this.recipeList[index].lastCookedDate = cookDate;
        }
      );
  }

  updatecomment(recipe: Recipe, comments: WComment[]){
    let requestHeader = new Headers({'Content-Type': 'application/json'});
    this.http.put("http://localhost:8080/updateComments/"+recipe.id, JSON.stringify(comments), {headers: requestHeader})
      .map((data: Response) => data.json())
      .catch(this.handleError)
      .subscribe(
        (data) => {
          var index = this.recipeList.indexOf(recipe);
          if( index === -1 ){
            return;
          }
          this.recipeList[index].comments = comments;
          this.commentUpdate.emit(this.recipeList[index]);
        }
      );
  }

  private handleError (error: any) {
    console.log(error);
    return Observable.throw(error.json());
  }

}
