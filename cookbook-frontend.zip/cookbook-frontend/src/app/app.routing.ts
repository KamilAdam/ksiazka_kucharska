import {CategoryListComponent} from "./components/category/category-list.component";
import {RouterModule, Routes} from "@angular/router";
import {IngredientListComponent} from "./components/ingredient/ingredient-list.component";
import {RecipeListComponent} from "./components/recipe/recipe-list.component";
import {RecipeViewComponent} from "./components/recipe/recipe-view.component";
import {RecipeAddComponent} from "./components/recipe/recipe-add.component";
import {RecipeEditComponent} from "./components/recipe/recipe-edit.component";
import {RecipeInComponent} from "./components/recipe/recipe-in.component";

const APP_ROUTES: Routes = [
  {
    path: '',
    redirectTo: '/przepisy',
    pathMatch: 'full'
  },
  {
    path: 'kategorie',
    component: CategoryListComponent
  },
  {
    path: 'skladniki',
    component: IngredientListComponent
  },
  {
    path: 'przepisy',
    component: RecipeListComponent
  },
  {
    path: 'przepis/:id',
    component: RecipeViewComponent
  },
  {
    path: 'nowy-przepis',
    component: RecipeAddComponent
  },
  {
    path: 'edytuj-przepis/:id',
    component: RecipeEditComponent
  },
  {
    path: 'przepisy/:type/:id',
    component: RecipeInComponent
  }
];

export const routing = RouterModule.forRoot(APP_ROUTES);
