import { Pipe, PipeTransform } from '@angular/core';
import {Recipe} from "../model/Recipe";

@Pipe({
  name: 'recipeSearch',
  pure: true
})
export class RecipePipe implements PipeTransform {

  transform(value: any, args?: any): any {

    if(value.length == 0 || args == null){
      return value;
    }

    if( args.option == 1 && args.status ){

      let var1 = false;
      let var2 = false;
      let resultArray = [];

      for(let item of value){

        var1 = false;
        var2 = false;

        if( args.name != "" ) {
          if (item.name.match('^.*' + args.name + '.*$')) {
            var1 = true;
          }
        }else{
          var1 = true;
        }

        if(args.ingredients.length > 0) {
          for (let ingredient of args.ingredients) {
            if( item.ingredients.indexOf(ingredient) !== -1 ){
              var2 = true;
              break;
            }
          }
        }else{
          var2 = true;
        }

        if(var1 && var2){
          resultArray.push(item);
        }

      }

      return resultArray;

    }else if( args.option == 2 && args.status ){

      let resultArray: Recipe[] = [];

      if( args.range == 2 ){
        for(let i = 0; i < value.length; i++){
          if( value[i].favorite ){
            resultArray.push( value[i] );
          }
        }
      }else{
        resultArray = value;
      }

      resultArray.sort((a: any, b: any) => {
        let a_var: any;
        let b_var: any;

        if( args.order == 2 ){
          a_var = a.lastCookedDate;
          b_var = b.lastCookedDate;
        }else if( args.order == 3 ){
          a_var = a.publishDate;
          b_var = b.publishDate;
        }else{
          a_var = a.name;
          b_var = b.name;
        }

        if( a_var < b_var ){
          return (args.by == 1) ? -1 : 1;
        }else if( a_var > b_var ){
          return (args.by == 1) ? 1 : -1;
        }else{
          return 0;
        }
      });

      return resultArray;

    }else if( args.option == 3 && args.status ){

      let resultArray: Recipe[] = [];
      let finalResultArray: Recipe[] = [];

      if( args.range == 2 ){
        for(let i = 0; i < value.length; i++){
          if( value[i].favorite ){
            resultArray.push( value[i] );
          }
        }
      }else{
        resultArray = value;
      }

      if( args.categories.length > 0 ){
        for( let recipe of resultArray ){
          var commonArray = [recipe.categories, args.categories];


          var res = commonArray.shift().filter(function (v) {
            return commonArray.every(function (a) {
              return a.indexOf(v) !== -1;
            });
          });
          if(res.length > 0){
            finalResultArray.push(recipe);
          }
        }
      }else{
        finalResultArray = resultArray;
      }

      if(finalResultArray.length > 0) {
       return [finalResultArray[Math.floor(Math.random() * finalResultArray.length)]];
      }else{
        return [];
      }
    }else{
      return value;
    }
    //return value;
  }

}
