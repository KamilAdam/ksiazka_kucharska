import {Component, OnInit, OnDestroy, Output, EventEmitter} from '@angular/core';
import {Input} from "@angular/core/src/metadata/directives";
import {Ingredient} from "../../model/Ingredient";
import {FormGroup, FormBuilder, Validators} from "@angular/forms";
import {IngredientService} from "../../services/ingredient.service";
import {RecipeService} from "../../services/recipe.service";

declare var $: any;

@Component({
  selector: 'app-ingredient-item',
  templateUrl: './ingredient-item.component.html'
})
export class IngredientItemComponent implements OnInit, OnDestroy {

  @Input() ingredient: Ingredient;
  @Output() validInfo = new EventEmitter();

  public editMode: boolean = false;
  private ingredientForm: FormGroup;
  public units = [];
  private recipesInIngredient: number = 0;

  private updateLoad: boolean = false;
  private deleteLoad: boolean = false;
  private errorObj: any = {title: "", kom: ""};

  constructor(private ingredientService: IngredientService, private formBuilder: FormBuilder, private recipeService: RecipeService) { }

  ngOnInit() {
    this.setDefaultUnits();
    this.initForm();
    this.recipesInIngredient = this.recipeService.getRecipesByIngredient(this.ingredient, false);
    this.ingredientService.updateEmitter.subscribe(
      (ingredient: Ingredient) => {
        if(ingredient == this.ingredient) {
          this.updateLoad = false;
          this.cancelEditIngredient();
        }
      }
    );
    $('.tooltipped').tooltip({delay: 50});
  }

  setDefaultUnits(){
    this.units = this.ingredient.units;
  }

  editIngredient(){
    this.editMode = true;
    this.resetTooltip();
  }

  deleteIngredient(){
    this.deleteLoad = true;
    this.ingredientService.deleteIngredient(this.ingredient);
    this.resetTooltip();
  }

  cancelEditIngredient(){
    this.setDefaultUnits();
    this.ingredientForm.controls['name'].setValue(this.ingredient.name);
    this.editMode = false;
    this.resetTooltip();
  }

  initForm(){
    this.ingredientForm = this.formBuilder.group({
      name: [this.ingredient.name, Validators.required]
    });
  }

  onSubmit(){
    this.updateLoad = true;
    if(this.ingredientForm.valid){
      if(this.ingredientService.freeIngredientExcerpt(this.ingredientForm.value.name, this.ingredient.name)){
        this.ingredientService.updateIngredient(this.ingredient, this.ingredientForm.value.name, this.units);
      }else{
        this.errorObj.kom = "Podana nazwa składnika jest już zajęta.";
        this.errorObj.title = "Błąd podczas edycji:";
        this.validInfo.emit(this.errorObj);
        this.updateLoad = false;
      }
    }else{
      this.errorObj.kom = "Proszę podać nazwę składnika i jego możliwe jednostki.";
      this.errorObj.title = "Błąd podczas edycji:";
      this.validInfo.emit(this.errorObj);
      this.updateLoad = false;
    }
  }

  resetTooltip(){
    $(".material-tooltip").remove();
    $('.tooltipped').tooltip({delay: 50});
  }

  ngOnDestroy(){
    this.resetTooltip();
  }

}
