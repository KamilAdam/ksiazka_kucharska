import { Component, OnInit } from '@angular/core';
import {Ingredient} from "../../model/Ingredient";
import {IngredientService} from "../../services/ingredient.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

declare var $: any;

@Component({
  selector: 'app-ingredient-list',
  templateUrl: './ingredient-list.component.html'
})
export class IngredientListComponent implements OnInit {

  private ingredients: Ingredient[];
  private addIngredientsForm: FormGroup;
  public units = [];

  private addLoad: boolean = false;

  private generatedIngredients: boolean = true;
  private error_com: string = "";
  private error_title: string = "Bład podczas dodawania:";

  constructor(private ingredientService: IngredientService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.ingredients = this.ingredientService.getIngredients();
    console.log("składników: " + this.ingredientService.getIngredientsCount());
    if(this.ingredientService.getIngredientsCount() > 0){
      this.generatedIngredients = false;
    }else {
      this.ingredientService.generateEmitter.subscribe(
        (ingredients: Ingredient[]) => {
          this.generatedIngredients = false;
          console.log("a teraz składników: " + this.ingredientService.getIngredientsCount());
        }
      );
    }

    this.initForm();
    this.ingredientService.addEmitter.subscribe(
      (ingredient: Ingredient) => {
        this.addLoad = false;
        this.addIngredientsForm.reset();
        this.units = [];
      }
    );
    $('.tooltipped').tooltip({delay: 50});
    $(".modal").modal();
  }

  initForm(){
    this.addIngredientsForm = this.formBuilder.group({
      name: ["", Validators.required]
    });
  }

  showItemError(kom: any){
    this.error_com = kom.kom;
    this.error_title = kom.title;
    $("#add-error-modal").modal('open');
  }

  onSubmit(){
    this.addLoad = true;
    if(this.addIngredientsForm.valid && this.units.length > 0){
      if(this.ingredientService.freeIngredient(this.addIngredientsForm.value.name)){
        this.ingredientService.addIngredient(this.addIngredientsForm.value.name, this.units);
      }else{
        this.addLoad = false;
        this.error_com = "Podana nazwa składnika jest już zajęta.";
        this.error_title = "Bład podczas dodawania:";
        $("#add-error-modal").modal('open');
      }
    }else{
      this.addLoad = false;
      this.error_com = "Proszę podać nazwę składnika i jego możliwe jednostki.";
      this.error_title = "Bład podczas dodawania:";
      $("#add-error-modal").modal('open');
    }
  }

}
