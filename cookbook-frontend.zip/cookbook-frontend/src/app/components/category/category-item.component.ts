import {Component, OnInit, OnDestroy, Output, EventEmitter} from '@angular/core';
import {Input} from "@angular/core/src/metadata/directives";
import {Category} from "../../model/Category";
import {CategoryService} from "../../services/category.service";
import {FormGroup, Validators, FormBuilder} from "@angular/forms";
import {RecipeService} from "../../services/recipe.service";

declare var $: any;

@Component({
  selector: 'app-category-item',
  templateUrl: './category-item.component.html'
})
export class CategoryItemComponent implements OnInit, OnDestroy {

  @Input() category:Category;
  @Output() validInfo = new EventEmitter();

  public editMode: boolean = false;
  private categoryForm: FormGroup;
  private recipesInCategory: number = 0;

  private updateLoad: boolean = false;
  private deleteLoad: boolean = false;
  private errorObj: any = {title: "", kom: ""};

  constructor(private categoryService: CategoryService, private formBuilder: FormBuilder, private recipeService: RecipeService) { }

  ngOnInit() {
    this.initForm();
    this.recipesInCategory = this.recipeService.getRecipesByCategory(this.category, false);
    this.categoryService.updateEmitter.subscribe(
      (categry: Category) => {
        if(categry == this.category) {
          this.updateLoad = false;
          this.cancelEditCategory();
        }
      }
    );
    $('.tooltipped').tooltip({delay: 50});
  }

  editCategory(){
    this.editMode = true;
    this.resetTooltip();
  }

  deleteCategory(){
    this.deleteLoad = true;
    this.categoryService.deleteCategory(this.category);
    this.resetTooltip();
  }

  cancelEditCategory(){
    this.editMode = false;
    this.categoryForm.controls['name'].setValue(this.category.name);
    this.resetTooltip();
  }

  initForm(){
    this.categoryForm = this.formBuilder.group({
      name: [this.category.name, Validators.required]
    });
  }

  onSubmit(){
    this.updateLoad = true;
    if(this.categoryForm.valid){
      if(this.categoryService.freeCategoryExcerpt(this.categoryForm.value.name, this.category.name)){
        this.categoryService.updateCategory(this.category, this.categoryForm.value.name);
      }else{
        this.errorObj.kom = "Podana nazwa kategorii jest już zajęta.";
        this.errorObj.title = "Błąd podczas edycji:";
        this.validInfo.emit(this.errorObj);
        this.updateLoad = false;
      }
    }else{
      this.errorObj.kom = "Proszę podać nazwę kategorii.";
      this.errorObj.title = "Błąd podczas edycji:";
      this.validInfo.emit(this.errorObj);
      this.updateLoad = false;
    }
  }

  resetTooltip(){
    $(".material-tooltip").remove();
    $('.tooltipped').tooltip({delay: 50});
  }

  ngOnDestroy(){
    this.resetTooltip();
  }


}
