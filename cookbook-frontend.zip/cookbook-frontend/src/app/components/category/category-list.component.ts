import { Component, OnInit } from '@angular/core';
import {CategoryService} from "../../services/category.service";
import {Category} from "../../model/Category";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

declare var $: any;

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
})
export class CategoryListComponent implements OnInit {

  private categories: Category[];
  private addCategoryForm: FormGroup;

  private addLoad: boolean = false;

  private generatedCategory: boolean = true;
  private error_com: string = "";
  private error_title: string = "Bład podczas dodawania:";

  constructor(private categoryService: CategoryService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.categories = this.categoryService.getCategories();

    if(this.categoryService.getCategoriesCount() > 0){
      this.generatedCategory = false;
    }else {
      this.categoryService.generateEmitter.subscribe(
        (category: Category[]) => {
          this.generatedCategory = false;
        }
      );
    }
    this.initForm();
    this.categoryService.addEmitter.subscribe(
      (category: Category) => {
        this.addLoad = false;
        this.addCategoryForm.reset();
      }
    );
    $('.tooltipped').tooltip({delay: 50});
    $(".modal").modal();
  }

  initForm(){
    this.addCategoryForm = this.formBuilder.group({
      name: ["", Validators.required]
    });
  }

  showItemError(kom: any){
    this.error_com = kom.kom;
    this.error_title = kom.title;
    $("#add-error-modal").modal('open');
  }

  onSubmit(){
    this.addLoad = true;
    if(this.addCategoryForm.valid){
      if(this.categoryService.freeCategory(this.addCategoryForm.value.name)) {
        this.categoryService.addCategory(this.addCategoryForm.value.name);
      }else{
        this.addLoad = false;
        this.error_com = "Podana nazwa kategorii jest już zajęta.";
        this.error_title = "Bład podczas dodawania:";
        $("#add-error-modal").modal('open');
      }
    }else{
      this.addLoad = false;
      this.error_com = "Proszę podać nazwę kategorii.";
      this.error_title = "Bład podczas dodawania:";
      $("#add-error-modal").modal('open');
    }
  }

}
