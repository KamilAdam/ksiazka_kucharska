import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-loader',
  template: `
  <div [ngStyle]="styles" class="preloader-wrapper {{size}} active">
    <div class="spinner-layer" [ngStyle]="{'border-color': color}">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div><div class="gap-patch">
        <div class="circle"></div>
      </div><div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
  `
})
export class LoaderComponent{

  @Input() styles: string = "";
  @Input() size: string = "";
  @Input() color: string = "";

}
