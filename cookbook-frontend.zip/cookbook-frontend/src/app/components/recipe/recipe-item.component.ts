import {Component, OnInit, Input, OnDestroy} from '@angular/core';
import {Recipe} from "../../model/Recipe";
import {RecipeService} from "../../services/recipe.service";

declare var $: any;

@Component({
  selector: 'app-recipe-item',
  templateUrl: './recipe-item.component.html'
})
export class RecipeItemComponent implements OnInit, OnDestroy {

  @Input() recipe: Recipe;

  private favouriteLoad: boolean = false;
  private deleteLoad: boolean = false;

  constructor(private recipeService: RecipeService) { }

  ngOnInit() {
    this.recipeService.favouriteLoad.subscribe(
      (recipe: Recipe) => {
        if(recipe == this.recipe) {
          this.favouriteLoad = false;
          this.resetTooltip();
        }
      }
    );
    $('.tooltipped').tooltip({delay: 50});
  }

  resetTooltip(){
    $(".material-tooltip").remove();
    $('.tooltipped').tooltip({delay: 50});
  }

  ngOnDestroy(){
    this.resetTooltip();
  }

  toggleFavourites(){
    this.favouriteLoad = true;
    this.recipeService.toggleFavourites(this.recipe);
  }

  deleteRecipe(){
    this.deleteLoad = true;
    this.recipeService.deleteRecipe(this.recipe);
  }

}
