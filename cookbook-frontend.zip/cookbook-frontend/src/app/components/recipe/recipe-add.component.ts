import { Component, OnInit } from '@angular/core';
import {RecipeService} from "../../services/recipe.service";
import {Category} from "../../model/Category";
import {CategoryService} from "../../services/category.service";
import {IngredientService} from "../../services/ingredient.service";
import {Recipe} from "../../model/Recipe";
import {Ingredient} from "../../model/Ingredient";
import {FormBuilder, FormGroup, Validators, FormArray, Form, FormControl} from "@angular/forms";
import {isNumber} from "util";
import {Router} from "@angular/router";
import {CustomIngredient} from "../../model/CustomIngredient";

declare var $: any;


@Component({
  selector: 'app-recipe-add',
  templateUrl: './recipe-add.component.html'
})
export class RecipeAddComponent implements OnInit {

  private newRecipe: Recipe = new Recipe(0, "", "", [], [], [], [], [], 0, 0, 0, 0, new Date(), new Date(), false);
  private ingredientList: Ingredient[] = [];
  private categoryList: Category[] = [];
  private recipeForm: FormGroup;
  private units: string[] = [];
  private ingredientsRefs: Ingredient[] = [];
  private ingredientsValues: CustomIngredient[] = [];
  private recipeDesc: string = "";

  private updateLoad: boolean = false;

  constructor(private router: Router, private recipeService: RecipeService, private categoryService: CategoryService, private ingredientService: IngredientService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.ingredientList = this.ingredientService.getIngredients();
    this.categoryList = this.categoryService.getCategories();
    this.initForm();
    $(".modal").modal();
    $('.tooltipped').tooltip({delay: 50});
  }

  initForm(){
    this.recipeForm = this.formBuilder.group({
      name: ["", Validators.required],
      prepareTime: [""],
      costsServing: [""],
      calories: [""],
      numberServing: [""],
      categories: [[''], Validators.required],
      customIngredient: new FormArray([]),
      ingredientsType: new FormArray([]),
    })
  }

  addIngredient(name: any, quantity: any, unit: any){
    if( name.value != "" && quantity.value != "" && unit.value != "" && this.ingredientService.getIngredientByName(name.value) != null ){
      (<FormArray>this.recipeForm.controls['ingredientsType']).push(
        new FormGroup({
          name: new FormControl(name.value, Validators.required),
          quantity: new FormControl(quantity.value, Validators.required),
          unit: new FormControl(unit.value, Validators.required)
        })
      );
      name.value = "";
      quantity.value = "";
      unit.value = "";
      unit.options.length = 1;
    }
  }

  addCustomIngredient(name: any, quantity: any, unit: any){
    if( name.value != "" && quantity.value != "" && unit.value != "" && this.ingredientService.freeIngredient(name.value) ){
      (<FormArray>this.recipeForm.controls['customIngredient']).push(
        new FormGroup({
          name: new FormControl(name.value, Validators.required),
          quantity: new FormControl(quantity.value, Validators.required),
          unit: new FormControl(unit.value, Validators.required)
        })
      );
      name.value = "";
      quantity.value = "";
      unit.value = "";

    }else{
      $("#add-error-modal-ing").modal('open');
    }
  }

  removeCustomIngredient(index:number){
    (<FormArray>this.recipeForm.controls['customIngredient']).removeAt(index);
  }

  removeIngredient(index:number){
    (<FormArray>this.recipeForm.controls['ingredientsType']).removeAt(index);
  }

  keyupHandlerFunction(x: any){
    this.recipeDesc = x;
  }

  show(el:any){
    console.log(el);
  }

  onSubmit(){
    if( this.recipeForm.valid && this.recipeForm.value.categories.length > 0 && ( this.recipeForm.value.customIngredient.length > 0 || this.recipeForm.value.ingredientsType.length > 0 ) ){

      this.updateLoad = true;

      this.ingredientsRefs = [];
      this.ingredientsValues = [];

      this.newRecipe.name = this.recipeForm.value.name;
      this.newRecipe.description = this.recipeDesc;
      this.newRecipe.categories = this.recipeForm.value.categories;

      if( this.recipeForm.value.prepareTime != "" && !isNaN(this.recipeForm.value.prepareTime) ){
        this.newRecipe.prepareTime = +this.recipeForm.value.prepareTime;
      }

      if( this.recipeForm.value.costsServing != "" && !isNaN(this.recipeForm.value.costsServing) ){
        this.newRecipe.costsServing = +this.recipeForm.value.costsServing;
      }

      if( this.recipeForm.value.numberServing != "" && !isNaN(this.recipeForm.value.numberServing) ){
        this.newRecipe.numberServing = +this.recipeForm.value.numberServing;
      }

      if( this.recipeForm.value.calories != "" && !isNaN(this.recipeForm.value.calories) ){
        this.newRecipe.calories = +this.recipeForm.value.calories;
      }

      if( this.recipeForm.value.customIngredient.length > 0 ){
        this.newRecipe.customIngredients = this.recipeForm.value.customIngredient;
      }

      if( this.recipeForm.value.ingredientsType.length > 0 ){
        for(let i = 0; i < this.recipeForm.value.ingredientsType.length; i++){
          this.ingredientsRefs.push(this.ingredientService.getIngredientByName(this.recipeForm.value.ingredientsType[i].name));
          this.ingredientsValues.push({
            quantity: this.recipeForm.value.ingredientsType[i].quantity,
            unit: this.recipeForm.value.ingredientsType[i].unit
          });
        }
        this.newRecipe.ingredients = this.ingredientsRefs;
        this.newRecipe.ingredientValues = this.ingredientsValues;
      }



      this.recipeService.addRecipe(this.newRecipe);

    }else{
      this.updateLoad = false;
      $("#add-error-modal").modal('open');
    }
  }

  loadUnits(el:any){
    this.units = this.ingredientService.getIngredientUnitByName(el);
  }

}

