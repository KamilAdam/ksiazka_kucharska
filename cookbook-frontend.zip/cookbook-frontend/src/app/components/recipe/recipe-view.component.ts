import {Component, OnInit, OnDestroy} from '@angular/core';
import {Subscription} from "rxjs/Rx";
import {Recipe} from "../../model/Recipe";
import {RecipeService} from "../../services/recipe.service";
import {ActivatedRoute, Router} from "@angular/router";
import {CategoryService} from "../../services/category.service";
import {Category} from "../../model/Category";
import {IngredientService} from "../../services/ingredient.service";
import {Ingredient} from "../../model/Ingredient";
import {FormControl, FormGroup, FormArray, Validators, FormBuilder} from "@angular/forms";
import {WComment} from "../../model/WComment";
import {Input} from "@angular/core/src/metadata/directives";

@Component({
  selector: 'app-recipe-view',
  templateUrl: './recipe-view.component.html'
})
export class RecipeViewComponent implements OnInit, OnDestroy {

  private subscription: Subscription;
  public recipe: Recipe = new Recipe(0, "", "", [], [], [], [], [], 0, 0, 0, 0, null, null, false);
  private lastCoockDate: Date;
  private recipeForm: FormGroup;
  private commentList: WComment[] = [];

  private commentUpdate: boolean = false;
  private favouriteLoad: boolean = false;
  private deleteLoad: boolean = false;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private recipeService: RecipeService, private categoryService: CategoryService, private ingredientService: IngredientService, private formBuilder: FormBuilder) { }

  @Input() randomRecipe: Recipe = null;

  ngOnInit() {
    this.subscription = this.activatedRoute.params.subscribe(
      (param: any) => {
        this.recipe = this.recipeService.getRecipe(param['id']);
        this.lastCoockDate = this.recipe.lastCookedDate;
      }
    );
    this.initForm();
    this.recipeService.commentUpdate.subscribe(
      (recipe: Recipe) => this.commentUpdate = false
    );
    this.recipeService.favouriteLoad.subscribe(
      (recipe: Recipe) => this.favouriteLoad = false
    );
    this.recipeService.deleteLoad.subscribe(
      (recipe: Recipe) => this.router.navigate(['/przepisy'])
    );
  }

  initForm(){
    let commentsList = new FormArray([]);
    for(let i = 0; i < this.recipe.comments.length; i++){
      commentsList.push(
        new FormGroup({
          content: new FormControl(this.recipe.comments[i].content)
        })
      );
    }

    this.recipeForm = this.formBuilder.group({
      commentsList: commentsList
    })
  }

  ngOnDestroy(){
    this.recipeService.updateLastCookDate(this.lastCoockDate, this.recipe);
    this.subscription.unsubscribe();
  }

  toggleFavourites(){
    this.favouriteLoad = true;
    this.recipeService.toggleFavourites(this.recipe);
  }

  deleteRecipe(){
    this.deleteLoad = true;
    this.recipeService.deleteRecipe(this.recipe);
  }

  addCommnet(content: any){
    if( content.value != "" ){
      (<FormArray>this.recipeForm.controls['commentsList']).push(
        new FormGroup({
          content: new FormControl(content.value, Validators.required),
        })
      );
      content.value = "";
    }
  }

  removeComment(index:number){
    (<FormArray>this.recipeForm.controls['commentsList']).removeAt(index);
  }

  onSubmit(){
    this.commentUpdate = true;
    this.commentList = [];
    if( this.recipeForm.value.commentsList.length > 0 ){
      for(let i = 0; i < this.recipeForm.value.commentsList.length; i++){
        this.commentList.push(new WComment(0, this.recipe.id, this.recipeForm.value.commentsList[i].content));
      }
    }
    this.recipeService.updatecomment(this.recipe, this.commentList);
  }

}
