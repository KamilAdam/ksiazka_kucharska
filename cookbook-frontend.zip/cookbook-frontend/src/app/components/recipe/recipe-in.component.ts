import {Component, OnInit, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute} from "@angular/router";
import {RecipeService} from "../../services/recipe.service";
import {CategoryService} from "../../services/category.service";
import {IngredientService} from "../../services/ingredient.service";
import {Subscription} from "rxjs";
import {Category} from "../../model/Category";
import {Ingredient} from "../../model/Ingredient";
import {Recipe} from "../../model/Recipe";

@Component({
  selector: 'app-recipe-in',
  templateUrl: './recipe-in.component.html'
})
export class RecipeInComponent implements OnInit, OnDestroy {

  private subscription: Subscription;
  private mainCategory: Category = null;
  private mainIngredient: Ingredient = null;
  private mainMode: number; //1 - kategoria, 2 - składnik
  private recipes: Recipe[] = [];

  constructor(private activatedRoute: ActivatedRoute, private recipeService: RecipeService, private categoryService: CategoryService, private ingredientService: IngredientService) { }

  ngOnInit() {
    this.subscription = this.activatedRoute.params.subscribe(
      (param: any) => {

        if( param['type'] == "kategoria" ){

          this.mainMode = 1;
          this.mainCategory = this.categoryService.getCategoryById(+param['id']);
          this.recipes = this.recipeService.getRecipesByCategory(this.mainCategory, true);

        }else if( param['type'] == "skladnik" ){

          this.mainMode = 2;
          this.mainIngredient = this.ingredientService.getIngredientById(+param['id']);
          this.recipes = this.recipeService.getRecipesByIngredient(this.mainIngredient, true);

        }

      }
    );
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
