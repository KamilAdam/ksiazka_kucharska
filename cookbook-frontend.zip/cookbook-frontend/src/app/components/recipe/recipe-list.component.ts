import {Component, OnInit, ViewChild, EventEmitter} from '@angular/core';
import {RecipeService} from "../../services/recipe.service";
import {Recipe} from "../../model/Recipe";
import {IngredientService} from "../../services/ingredient.service";
import {CategoryService} from "../../services/category.service";
import {Ingredient} from "../../model/Ingredient";
import {Category} from "../../model/Category";
import {RecipeViewComponent} from "./recipe-view.component";

declare var $: any;

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html'
})
export class RecipeListComponent implements OnInit {

  private recipes: Recipe[];
  private ingredientList: Ingredient[] = this.ingredientService.getIngredients();
  private categoryList: Category[] = this.categoryService.getCategories();

  private t1_ingredients = [];
  private t1_name = "";

  private t2_order = 0;
  private t2_by = 0;
  private t2_range = 0;

  private t3_categories = [];
  private t3_range = 0;

  private filterOption = 0;
  private filterStatus = false;
  private filterObject = null;

  private generatedRecipes: boolean = true;

  constructor(private recipeService: RecipeService, private ingredientService: IngredientService, private categoryService: CategoryService) { }

  ngOnInit() {
    this.recipes = this.recipeService.getRecipes();
    if(this.recipeService.getRecipesCount() > 0){
      this.generatedRecipes = false;
    }else {
      this.recipeService.generatedRecipes.subscribe(
        (recipes: Recipe[]) => {
          this.generatedRecipes = false;
          $('.tooltipped').tooltip({delay: 50});
          $('.modal').modal();
          $('ul.tabs').tabs();
        }
      );
    }
    $('.tooltipped').tooltip({delay: 50});
    $('.modal').modal();
    $('ul.tabs').tabs();
  }

  setFilterObject(filterOptionNumber: number){
    $('.modal').modal('close');
    this.filterStatus = true;
    this.filterObject = {
      option: filterOptionNumber,
      status: this.filterStatus,
    }
  }

  applayFirstForm(){
    if( this.t1_name != "" || this.t1_ingredients.length > 0 ) {
      this.setFilterObject(1);
      this.filterObject.name = this.t1_name;
      this.filterObject.ingredients = this.t1_ingredients;
    }
  }

  applaySecondForm(){
    if( this.t2_order != 0 && this.t2_range != 0 && this.t2_by != 0 ) {
      this.setFilterObject(2);
      this.filterObject.order = this.t2_order;
      this.filterObject.by = this.t2_by;
      this.filterObject.range = this.t2_range;
    }
  }

  applayThirdForm(){
    if( this.t3_range != 0 ){
      this.setFilterObject(3);
      this.filterObject.range = this.t3_range;
      this.filterObject.categories = this.t3_categories;
    }
  }

  disableFilter(){
    this.filterStatus = false;
  }

}
