import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators, FormArray, FormControl} from "@angular/forms";
import {Ingredient} from "../../model/Ingredient";
import {Category} from "../../model/Category";
import {Recipe} from "../../model/Recipe";
import {Subscription} from "rxjs";
import {ActivatedRoute, Router} from "@angular/router";
import {RecipeService} from "../../services/recipe.service";
import {CategoryService} from "../../services/category.service";
import {IngredientService} from "../../services/ingredient.service";
import {WComment} from "../../model/WComment";

declare var $: any;

@Component({
  selector: 'app-recipe-edit',
  templateUrl: './recipe-edit.component.html'
})
export class RecipeEditComponent implements OnInit {

  private recipe: Recipe = new Recipe(0, "", "", [], [], [], [], [], 0, 0, 0, 0, new Date(), new Date(), false);
  private newRecipe: Recipe = new Recipe(0, "", "", [], [], [], [], [], 0, 0, 0, 0, new Date(), new Date(), false);
  private ingredientList: Ingredient[] = [];
  private categoryList: Category[] = [];
  private recipeForm: FormGroup;
  private units: string[] = [];
  private ingredientsRefs: Ingredient[] = [];
  private ingredientsValues: Object[] = [];
  private subscription: Subscription;
  private lastCoockDate: Date;
  private recipeDesc: string = "";

  private updateLoad: boolean = false;
  private favouriteLoad: boolean = false;
  private deleteLoad: boolean = false;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private recipeService: RecipeService, private categoryService: CategoryService, private ingredientService: IngredientService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.subscription = this.activatedRoute.params.subscribe(
      (param: any) => {
        this.recipe = this.recipeService.getRecipe(param['id']);
        this.ingredientList = this.ingredientService.getIngredients();
        this.categoryList = this.categoryService.getCategories();
        this.initForm();
        this.lastCoockDate = this.recipe.lastCookedDate;
        this.recipeDesc = this.recipe.description;
      }
    );
    this.recipeService.favouriteLoad.subscribe(
      (recipe: Recipe) => this.favouriteLoad = false
    );
    this.recipeService.deleteLoad.subscribe(
      (recipe: Recipe) => this.router.navigate(['/przepisy'])
    );
    $(".modal").modal();
    $('.tooltipped').tooltip({delay: 50});
  }

  initForm(){

    let customIngredient = new FormArray([]);
    for(let i = 0; i < this.recipe.customIngredients.length; i++){
      customIngredient.push(
        new FormGroup({
          name: new FormControl(this.recipe.customIngredients[i].name, Validators.required),
          quantity: new FormControl(this.recipe.customIngredients[i].quantity, Validators.required),
          unit: new FormControl(this.recipe.customIngredients[i].unit, Validators.required)
        })
      );
    }

    let ingredientsType = new FormArray([]);
    for(let i = 0; i < this.recipe.ingredients.length; i++){
      ingredientsType.push(
        new FormGroup({
          name: new FormControl(this.recipe.ingredients[i].name, Validators.required),
          quantity: new FormControl(this.recipe.ingredientValues[i].quantity, Validators.required),
          unit: new FormControl(this.recipe.ingredientValues[i].unit, Validators.required)
        })
      );
    }

    let commentsList = new FormArray([]);
    for(let i = 0; i < this.recipe.comments.length; i++){
      commentsList.push(
        new FormGroup({
          content: new FormControl(this.recipe.comments[i].content)
        })
      );
    }

    this.recipeForm = this.formBuilder.group({
      name: [this.recipe.name, Validators.required],
      prepareTime: [this.recipe.prepareTime],
      costsServing: [this.recipe.costsServing],
      calories: [this.recipe.calories],
      numberServing: [this.recipe.numberServing],
      categories: [this.recipe.categories, Validators.required],
      customIngredient: customIngredient,
      ingredientsType: ingredientsType,
      commentsList: commentsList
    })
  }

  addIngredient(name: any, quantity: any, unit: any){
    if( name.value != "" && quantity.value != "" && unit.value != "" && this.ingredientService.getIngredientByName(name.value) != null ){
      (<FormArray>this.recipeForm.controls['ingredientsType']).push(
        new FormGroup({
          name: new FormControl(name.value, Validators.required),
          quantity: new FormControl(quantity.value, Validators.required),
          unit: new FormControl(unit.value, Validators.required)
        })
      );
      name.value = "";
      quantity.value = "";
      unit.value = "";
      unit.options.length = 1;
    }
  }

  addCustomIngredient(name: any, quantity: any, unit: any){
    if( name.value != "" && quantity.value != "" && unit.value != "" && this.ingredientService.freeIngredient(name.value) ){
      (<FormArray>this.recipeForm.controls['customIngredient']).push(
        new FormGroup({
          name: new FormControl(name.value, Validators.required),
          quantity: new FormControl(quantity.value, Validators.required),
          unit: new FormControl(unit.value, Validators.required)
        })
      );
      name.value = "";
      quantity.value = "";
      unit.value = "";
    }else{
      $("#add-error-modal-ing").modal('open');
    }
  }

  addCommnet(content: any){
    if( content.value != "" ){
      (<FormArray>this.recipeForm.controls['commentsList']).push(
        new FormGroup({
          content: new FormControl(content.value, Validators.required),
        })
      );
      content.value = "";
    }
  }

  removeCustomIngredient(index:number){
    (<FormArray>this.recipeForm.controls['customIngredient']).removeAt(index);
  }

  removeComment(index:number){
    (<FormArray>this.recipeForm.controls['commentsList']).removeAt(index);
  }

  removeIngredient(index:number){
    (<FormArray>this.recipeForm.controls['ingredientsType']).removeAt(index);
  }

  loadUnits(el:any){
    this.units = this.ingredientService.getIngredientUnitByName(el);
  }

  keyupHandlerFunction(x: any){
    this.recipeDesc = x;
  }

  onSubmit(){
    if( this.recipeDesc != "" && this.recipeForm.valid && this.recipeForm.value.categories.length > 0 && ( this.recipeForm.value.customIngredient.length > 0 || this.recipeForm.value.ingredientsType.length > 0 ) ){

      this.updateLoad = true;

      this.ingredientsRefs = [];
      this.ingredientsValues = [];

      this.newRecipe.lastCookedDate = this.lastCoockDate;
      this.newRecipe.id = this.recipe.id;
      this.newRecipe.name = this.recipeForm.value.name;
      this.newRecipe.description = this.recipeDesc;
      this.newRecipe.categories = this.recipeForm.value.categories;

      if( this.recipeForm.value.prepareTime != "" && !isNaN(this.recipeForm.value.prepareTime) ){
        this.newRecipe.prepareTime = +this.recipeForm.value.prepareTime;
      }

      if( this.recipeForm.value.costsServing != "" && !isNaN(this.recipeForm.value.costsServing) ){
        this.newRecipe.costsServing = +this.recipeForm.value.costsServing;
      }

      if( this.recipeForm.value.numberServing != "" && !isNaN(this.recipeForm.value.numberServing) ){
        this.newRecipe.numberServing = +this.recipeForm.value.numberServing;
      }

      if( this.recipeForm.value.calories != "" && !isNaN(this.recipeForm.value.calories) ){
        this.newRecipe.calories = +this.recipeForm.value.calories;
      }

      if( this.recipeForm.value.customIngredient.length > 0 ){
        this.newRecipe.customIngredients = this.recipeForm.value.customIngredient;
      }

      if( this.recipeForm.value.ingredientsType.length > 0 ){
        for(let i = 0; i < this.recipeForm.value.ingredientsType.length; i++){
          this.ingredientsRefs.push(this.ingredientService.getIngredientByName(this.recipeForm.value.ingredientsType[i].name));
          this.ingredientsValues.push({
            quantity: this.recipeForm.value.ingredientsType[i].quantity,
            unit: this.recipeForm.value.ingredientsType[i].unit
          });
        }
        this.newRecipe.ingredients = this.ingredientsRefs;
        this.newRecipe.ingredientValues = this.ingredientsValues;
      }

      this.newRecipe.comments = [];
      if( this.recipeForm.value.commentsList.length > 0 ){
        for(let i = 0; i < this.recipeForm.value.commentsList.length; i++){
          this.newRecipe.comments.push(new WComment(0, this.recipe.id, this.recipeForm.value.commentsList[i].content));
        }
      }

      this.recipeService.updateRecipe(this.recipe, this.newRecipe);
    }else{
      this.updateLoad = false;
      $("#add-error-modal").modal('open');
    }
  }

  toggleFavourites(){
    this.favouriteLoad = true;
    this.recipeService.toggleFavourites(this.recipe);
  }

  deleteRecipe(){
    this.deleteLoad = true;
    this.recipeService.deleteRecipe(this.recipe);
  }

}
