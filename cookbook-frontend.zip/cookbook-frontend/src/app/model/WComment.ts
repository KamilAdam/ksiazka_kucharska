export class WComment{
  constructor(
    public id: number,
    public recipeId: number,
    public content: string
  ){}
}
