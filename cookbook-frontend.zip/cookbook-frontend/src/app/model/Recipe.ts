import {Category} from "./Category";
import {Ingredient} from "./Ingredient";
import {CustomIngredient} from "./CustomIngredient";
import {WComment} from "./WComment";

export class Recipe{
  constructor(
    public id: number,
    public name: string,
    public description: string,
    public categories: Category[],
    public ingredients: Ingredient[],
    public ingredientValues: any[],
    public customIngredients: CustomIngredient[],
    public comments: WComment[],
    public prepareTime: number,
    public costsServing: number,
    public calories: number,
    public numberServing: number,
    public publishDate: Date,
    public lastCookedDate: Date,
    public favorite: boolean
  ){}
}
