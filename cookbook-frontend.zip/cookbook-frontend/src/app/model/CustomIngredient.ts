export class CustomIngredient{
  constructor(
    public name?: string,
    public quantity?: string,
    public unit?: string
  ){}
}
