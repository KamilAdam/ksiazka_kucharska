$(document).ready(function(){
	$('.tooltipped').tooltip({delay: 50});
	//$('.modal').modal();
	//$('select').material_select();
});
