package pl.jukidesigner.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pl.jukidesigner.model.Ingredient;
import pl.jukidesigner.service.IngredientService;

import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@RestController
@RequestMapping("/ingredient")
public class IngredientController {

    @Autowired
    IngredientService ingredientService;

    @RequestMapping(method = RequestMethod.GET)
    public List<Ingredient> categoryList(){
        return ingredientService.getAll();
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public int add(@RequestBody Ingredient ingredient){
        return ingredientService.add(ingredient);
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public boolean delete(@PathVariable int id){
        return ingredientService.delete(id);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public boolean edit(@RequestBody Ingredient ingredient){
        return ingredientService.edit(ingredient);
    }

}
