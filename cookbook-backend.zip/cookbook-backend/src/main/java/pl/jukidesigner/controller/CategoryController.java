package pl.jukidesigner.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pl.jukidesigner.model.Category;
import pl.jukidesigner.service.CategoryService;

import java.util.Collection;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    CategoryService categoryService;

    @RequestMapping(method = RequestMethod.GET)
    public List<Category> categoryList(){
        return categoryService.getAll();
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public int add(@RequestBody Category category){
        return categoryService.add(category);
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public boolean delete(@PathVariable int id){
        return categoryService.delete(id);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public boolean edit(@RequestBody Category category){
        return categoryService.edit(category);
    }

}