package pl.jukidesigner.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pl.jukidesigner.model.Category;
import pl.jukidesigner.model.Comment;
import pl.jukidesigner.model.Recipe;
import pl.jukidesigner.service.RecipeService;

import java.util.Date;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@RestController
@RequestMapping("/")
public class RecipeController {

    @Autowired
    RecipeService recipeService;

    @RequestMapping(method = RequestMethod.GET)
    public List<Recipe> categoryList(){
        return recipeService.getAll();
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public int add(@RequestBody Recipe recipe){
        return recipeService.add(recipe);
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public boolean delete(@PathVariable int id){
        return recipeService.delete(id);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public boolean edit(@RequestBody Recipe recipe){
        return recipeService.edit(recipe);
    }

    @RequestMapping(value = "/toggleFavorite/{id}/{currentStatus}", method = RequestMethod.PUT)
    public boolean toggle(@PathVariable int id, @PathVariable boolean currentStatus){
        return recipeService.toggleFavorite(id, currentStatus);
    }

    @RequestMapping(value = "/updateComments/{id}", method = RequestMethod.PUT)
    public boolean updateComments(@PathVariable int id, @RequestBody List<Comment> comments){
        return recipeService.updateComments(comments, id);
    }

    @RequestMapping(value = "/updateLastCookDate/{id}/{date}", method = RequestMethod.PUT)
    public boolean updateLastCookDate(@PathVariable int id, @PathVariable Date date){
        return recipeService.updateLastCookDate(id, date);
    }

}
