package pl.jukidesigner.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/**
 * Created by Piotr Stachurski on 19.01.2017.
 */

@Configuration
public class DataSourceConfiguration {

    @Bean
    public DataSource dataSource(){
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/cookbook?useUnicode=yes&characterEncoding=UTF-8&useSSL=false");
        dataSource.setUsername("root");
        dataSource.setPassword("");
        //dataSource.setUrl("jdbc:mysql://mysql7.hekko.net.pl:3306/juki_cookbook?useUnicode=yes&characterEncoding=UTF-8&useSSL=false");
        //dataSource.setUsername("juki_designer");
        //dataSource.setPassword("12.StudiO.12");
        return dataSource;
    }

    @Bean
    public JdbcOperations jdbcOperations(DataSource dataSource){
        return new JdbcTemplate(dataSource);
    }

}
