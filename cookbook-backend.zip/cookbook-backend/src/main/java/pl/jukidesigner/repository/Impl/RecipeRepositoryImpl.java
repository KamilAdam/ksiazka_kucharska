package pl.jukidesigner.repository.Impl;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import pl.jukidesigner.model.Comment;
import pl.jukidesigner.model.CustomIngredient;
import pl.jukidesigner.model.IngredientValue;
import pl.jukidesigner.model.Recipe;
import pl.jukidesigner.repository.CategoryRepository;
import pl.jukidesigner.repository.RecipeRepository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Repository
public class RecipeRepositoryImpl implements RecipeRepository {

    private static final String SQL_SELECT = "SELECT id, name, description, custom_ingredients, prepare_time, costs_serving, calories, number_serving, publish_date, last_cooked_date, favorite FROM recipe";
    private static final String SQL_ADD_CATEGORY = "INSERT INTO recipe_category (recipe_id, category_id) VALUES (?, ?)";
    private static final String SQL_ADD_INGREDIENTS = "INSERT INTO recipe_ingredient (recipe_id, ingredient_id, quantity, unit) VALUES (?, ?, ?, ?)";
    private static final String SQL_ADD_COMMENTS = "INSERT INTO comment (recipe_id, content) VALUES (?, ?)";
    private static final String SQL_SELECT_CATEGORY = "SELECT category_id FROM recipe_category WHERE recipe_id = ?";
    private static final String SQL_SELECT_COMMENTS = "SELECT id, recipe_id, content FROM comment WHERE recipe_id = ?";
    private static final String SQL_SELECT_INGREDIENTS = "SELECT recipe_id, ingredient_id, quantity, unit FROM recipe_ingredient WHERE recipe_id = ?";

    private static final String SQL_UPDATE = "UPDATE recipe SET name = ?, description = ?, custom_ingredients = ?, prepare_time = ?, costs_serving = ?, calories = ?, number_serving = ?, publish_date = ?, last_cooked_date = ?, favorite = ? WHERE id = ?";
    private static final String SQL_UPDATE_LAST_COOK_DATE = "UPDATE recipe SET last_cooked_date = ? WHERE id = ?";
    private static final String SQL_FAVORITE_UPDATE = "UPDATE recipe SET favorite = ? WHERE id = ?";
    private static final String SQL_DELETE_CATEGORY = "DELETE FROM recipe_category WHERE recipe_id = ?";
    private static final String SQL_DELETE_INGREDIENTS = "DELETE FROM recipe_ingredient WHERE recipe_id = ?";
    private static final String SQL_DELETE_COMMENTS = "DELETE FROM comment WHERE recipe_id = ?";
    private static final String SQL_DELETE = "DELETE FROM recipe WHERE id = ?";

    @Autowired
    private JdbcOperations jdbcOperations;

    public List<Recipe> getAll() {

        List<Recipe> recipes = jdbcOperations.query(SQL_SELECT, new RecipeRowMapper());
        List<Map<String, String>> ingredientObject;

        for(Recipe recipe: recipes){
            recipe.setCategories(jdbcOperations.query(SQL_SELECT_CATEGORY, new CategoryFromRecipeRowMapper(), recipe.getId()));
            recipe.setComments(jdbcOperations.query(SQL_SELECT_COMMENTS, new CommentsFromRecipeRowMapper(), recipe.getId()));
            ingredientObject = jdbcOperations.query(SQL_SELECT_INGREDIENTS, new IngredientsFromRecipeRowMapper(), recipe.getId());

            if(recipe.getCategories() == null) {
                recipe.setCategories(new ArrayList<Integer>());
            }

            if(ingredientObject.size() > 0 && ingredientObject != null){
                List<Integer> integersIds = new ArrayList<Integer>();
                List<IngredientValue> ingredientValues = new ArrayList<IngredientValue>();
                for(int j = 0; j < ingredientObject.size(); j++){
                    integersIds.add(Integer.valueOf(ingredientObject.get(j).get("ingredient_id")));
                    ingredientValues.add( new IngredientValue(ingredientObject.get(j).get("quantity"), ingredientObject.get(j).get("unit")) );
                }
                recipe.setIngredients(integersIds);
                recipe.setIngredientValues(ingredientValues);
            }else{
                recipe.setIngredients(new ArrayList<Integer>());
                recipe.setIngredientValues(new ArrayList<IngredientValue>());
            }

        }

        return recipes;
    }

    public int add(Recipe recipe) {
        SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert((JdbcTemplate) jdbcOperations).withTableName("recipe");
        jdbcInsert.setGeneratedKeyNames("id");
        Map<String, Object> args = new HashMap<String, Object>();
        args.put("name", recipe.getName());
        args.put("description", recipe.getDescription());
        args.put("prepare_time", recipe.getPrepareTime());
        args.put("costs_serving", recipe.getCostsServing());
        args.put("calories", recipe.getCalories());
        args.put("number_serving", recipe.getNumberServing());
        args.put("publish_date", recipe.getPublishDate());
        args.put("last_cooked_date", recipe.getLastCookedDate());

        if( recipe.isFavorite() ){
            args.put("favorite", 1);
        }else{
            args.put("favorite", 0);
        }

        if( recipe.getCustomIngredients().size() > 0 && recipe.getCustomIngredients() != null ){
            args.put("custom_ingredients", recipe.getCustomIngredients().toString());
        }else{
            args.put("custom_ingredients", "[]");
        }

        int id = jdbcInsert.executeAndReturnKey(args).intValue();

        if( recipe.getCategories().size() > 0 && recipe.getCategories() != null ){
            for(Integer cat: recipe.getCategories()){
                jdbcOperations.update(SQL_ADD_CATEGORY, id, cat);
            }
        }

        if( recipe.getIngredients().size() > 0 && recipe.getIngredients() != null && recipe.getIngredientValues().size() > 0 && recipe.getIngredientValues() != null && recipe.getIngredients().size() == recipe.getIngredientValues().size()){
            for(int i = 0; i < recipe.getIngredients().size(); i++){
                jdbcOperations.update(SQL_ADD_INGREDIENTS, id, recipe.getIngredients().get(i), recipe.getIngredientValues().get(i).getQuantity(), recipe.getIngredientValues().get(i).getUnit());
            }
        }

        return id;
    }

    public boolean edit(Recipe recipe) {

        int favorite = (recipe.isFavorite()) ? 1 : 0;

        List<CustomIngredient> customIngredients =
                (recipe.getCustomIngredients().size() > 0 && recipe.getCustomIngredients() != null)
                        ? recipe.getCustomIngredients()
                        : new ArrayList<CustomIngredient>();

        jdbcOperations.update(SQL_DELETE_CATEGORY, recipe.getId());
        jdbcOperations.update(SQL_DELETE_INGREDIENTS, recipe.getId());
        jdbcOperations.update(SQL_DELETE_COMMENTS, recipe.getId());

        for(Integer catId: recipe.getCategories()){
            jdbcOperations.update(SQL_ADD_CATEGORY, recipe.getId(), catId);
        }

        for(int i = 0; i < recipe.getIngredients().size(); i++){
            jdbcOperations.update(SQL_ADD_INGREDIENTS, recipe.getId(), recipe.getIngredients().get(i), recipe.getIngredientValues().get(i).getQuantity(), recipe.getIngredientValues().get(i).getUnit());
        }

        for(Comment comment: recipe.getComments()){
            jdbcOperations.update(SQL_ADD_COMMENTS, recipe.getId(), comment.getContent());
        }

        int result = jdbcOperations.update(
                SQL_UPDATE,
                recipe.getName(),
                recipe.getDescription(),
                customIngredients.toString(),
                recipe.getPrepareTime(),
                recipe.getCostsServing(),
                recipe.getCalories(),
                recipe.getNumberServing(),
                recipe.getPublishDate(),
                recipe.getLastCookedDate(),
                favorite,
                recipe.getId()
        );//komentarzami

        return (result > 0) ? true : false;
    }

    public boolean delete(int recipeId) {
        jdbcOperations.update(SQL_DELETE_CATEGORY, recipeId);
        jdbcOperations.update(SQL_DELETE_INGREDIENTS, recipeId);
        jdbcOperations.update(SQL_DELETE_COMMENTS, recipeId);
        return (jdbcOperations.update(SQL_DELETE, recipeId) > 0) ? true : false;
    }

    public boolean updateComments(List<Comment> comments, int recipeId){
        jdbcOperations.update(SQL_DELETE_COMMENTS, recipeId);
        for(Comment comment: comments){
            jdbcOperations.update(SQL_ADD_COMMENTS, recipeId, comment.getContent());
        }
        return true;
    }

    public boolean updateLastCookDate(int recipeId, Date date){
        return (jdbcOperations.update(SQL_UPDATE_LAST_COOK_DATE, date, recipeId) > 0) ? true : false;
    }

    private static final class RecipeRowMapper implements RowMapper<Recipe>{
        public Recipe mapRow(ResultSet rs, int rowNum) throws SQLException{
            Recipe recipe = new Recipe();
            recipe.setId(rs.getInt("id"));
            recipe.setName(rs.getString("name"));
            recipe.setDescription(rs.getString("description"));
            recipe.setPrepareTime(rs.getInt("prepare_time"));
            recipe.setCostsServing(rs.getInt("costs_serving"));
            recipe.setCalories(rs.getInt("calories"));
            recipe.setNumberServing(rs.getInt("number_serving"));
            recipe.setPublishDate(rs.getDate("publish_date"));
            recipe.setLastCookedDate(rs.getDate("last_cooked_date"));

            if( rs.getInt("favorite") == 1 ){
                recipe.setFavorite(true);
            }else{
                recipe.setFavorite(false);
            }

            if( !rs.getString("custom_ingredients").equals("[]") ){
                JSONArray jsonArray = new JSONArray(rs.getString("custom_ingredients"));
                List<CustomIngredient> customIngredients = new ArrayList<CustomIngredient>(jsonArray.length());
                for(int i = 0; i < jsonArray.length(); i++){
                    customIngredients.add(new CustomIngredient(
                            jsonArray.getJSONObject(i).getString("name"),
                            jsonArray.getJSONObject(i).getString("quantity"),
                            jsonArray.getJSONObject(i).getString("unit")
                    ));
                }
                recipe.setCustomIngredients(customIngredients);
            }else{
                recipe.setCustomIngredients(new ArrayList<CustomIngredient>());
            }

            return recipe;
        }

    }

    public boolean toggleFavorite(int recipeId, boolean currentStatus){
        return (jdbcOperations.update(SQL_FAVORITE_UPDATE, (currentStatus) ? 0 : 1, recipeId) > 0) ? true : false;
    }

    private static final class CategoryFromRecipeRowMapper implements RowMapper<Integer> {
        public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
            return rs.getInt("category_id");
        }
    }

    private static final class CommentsFromRecipeRowMapper implements RowMapper<Comment> {
        public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new Comment(rs.getInt("id"), rs.getInt("recipe_id"), rs.getString("content"));
        }
    }

    private static final class IngredientsFromRecipeRowMapper implements RowMapper<Map<String, String>> {
        public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
            Map<String, String> ingredient = new HashMap<String, String>();
            ingredient.put("ingredient_id", Integer.toString(rs.getInt("ingredient_id")));
            ingredient.put("quantity", rs.getString("quantity"));
            ingredient.put("unit", rs.getString("unit"));
            return ingredient;
        }
    }

}
