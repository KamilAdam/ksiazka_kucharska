package pl.jukidesigner.repository.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import pl.jukidesigner.model.Ingredient;
import pl.jukidesigner.repository.IngredientRepository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import org.json.*;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Repository
public class IngredientRepositoryImpl implements IngredientRepository{

    private static final String SQL_SELECT = "SELECT id, name, units FROM ingredient";
    private static final String SQL_DELETE = "DELETE FROM ingredient WHERE id = ?";
    private static final String SQL_UPDATE = "UPDATE ingredient SET name = ?, units = ? WHERE id = ?";
    private static final String SQL_DELETE_INGREDIENTS = "DELETE FROM recipe_ingredient WHERE ingredient_id = ?";

    @Autowired
    private JdbcOperations jdbcOperations;

    public List<Ingredient> getAll() {
        return jdbcOperations.query(SQL_SELECT, new IngredientsRowMapper());
    }

    public int add(Ingredient ingredient) {
        SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert((JdbcTemplate) jdbcOperations).withTableName("ingredient");
        jdbcInsert.setGeneratedKeyNames("id");
        Map<String, Object> args = new HashMap<String, Object>();
        args.put("name", ingredient.getName());
        args.put("units", ingredient.getUnits().toString());
        int id = jdbcInsert.executeAndReturnKey(args).intValue();
        return id;
    }

    public boolean edit(Ingredient ingredient){
        int result = jdbcOperations.update(SQL_UPDATE, ingredient.getName(), ingredient.getUnits().toString(), ingredient.getId());
        if( result > 0 ){
            return true;
        }else{
            return false;
        }
    }

    public boolean delete(int ingredientId) {
        jdbcOperations.update(SQL_DELETE_INGREDIENTS, ingredientId);
        int result = jdbcOperations.update(SQL_DELETE, ingredientId);
        if( result > 0 ){
            return true;
        }else{
            return false;
        }
    }

    private static final class IngredientsRowMapper implements RowMapper<Ingredient>{
        public Ingredient mapRow(ResultSet rs, int rowNum) throws SQLException{
            JSONArray jsonArray = new JSONArray(rs.getString("units"));
            List<String> units = new ArrayList<String>(jsonArray.length());
            for(int i = 0; i < jsonArray.length(); i++){
                units.add( jsonArray.get(i).toString() );
            }
            return new Ingredient(rs.getInt("id"), rs.getString("name"), units);
        }
    }

}
