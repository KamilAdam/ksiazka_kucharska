package pl.jukidesigner.repository.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import pl.jukidesigner.model.Category;
import pl.jukidesigner.repository.CategoryRepository;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Repository
public class CategoryRepositoryImpl implements CategoryRepository {

    private static final String SQL_SELECT = "SELECT id, name FROM category";
    private static final String SQL_DELETE = "DELETE FROM category WHERE id = ?";
    private static final String SQL_UPDATE = "UPDATE category SET name = ? WHERE id = ?";
    private static final String SQL_DELETE_CATEGORY = "DELETE FROM recipe_category WHERE category_id = ?";

    @Autowired
    private JdbcOperations jdbcOperations;

    public List<Category> getAll() {
        return jdbcOperations.query(SQL_SELECT, new CategoryRowMapper());
    }

    public int add(Category category) {
        SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert((JdbcTemplate) jdbcOperations).withTableName("category");
        jdbcInsert.setGeneratedKeyNames("id");
        Map<String, Object> args = new HashMap<String, Object>();
        args.put("name", category.getName());
        int id = jdbcInsert.executeAndReturnKey(args).intValue();
        return id;
    }

    public boolean edit(Category category) {
        int result = jdbcOperations.update(SQL_UPDATE, category.getName(), category.getId());
        if( result > 0 ){
            return true;
        }else{
            return false;
        }
    }

    public boolean delete(int categoryId) {
        jdbcOperations.update(SQL_DELETE_CATEGORY, categoryId);
        int result = jdbcOperations.update(SQL_DELETE, categoryId);
        if( result > 0 ){
            return true;
        }else{
            return false;
        }
    }

    private static final class CategoryRowMapper implements RowMapper<Category>{
        public Category mapRow(ResultSet rs, int rowNum) throws SQLException{
            return new Category(rs.getInt("id"), rs.getString("name"));
        }
    }

}
