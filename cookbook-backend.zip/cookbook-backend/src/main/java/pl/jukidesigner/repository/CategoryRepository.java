package pl.jukidesigner.repository;

import pl.jukidesigner.model.Category;

import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public interface CategoryRepository {

    public List<Category> getAll();
    public int add(Category category);
    public boolean edit(Category category);
    public boolean delete(int categoryId);

}
