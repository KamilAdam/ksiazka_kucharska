package pl.jukidesigner.service;

import pl.jukidesigner.model.Comment;
import pl.jukidesigner.model.Recipe;

import java.util.Date;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public interface RecipeService {

    public List<Recipe> getAll();
    public int add(Recipe recipe);
    public boolean edit(Recipe recipe);
    public boolean delete(int recipeId);
    public boolean toggleFavorite(int recipeId, boolean currentStatus);
    public boolean updateComments(List<Comment> comments, int recipeId);
    public boolean updateLastCookDate(int recipeId, Date date);
}
