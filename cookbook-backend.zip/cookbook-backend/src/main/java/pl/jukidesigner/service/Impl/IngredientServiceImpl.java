package pl.jukidesigner.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.jukidesigner.model.Ingredient;
import pl.jukidesigner.repository.IngredientRepository;
import pl.jukidesigner.service.IngredientService;

import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Service
public class IngredientServiceImpl implements IngredientService{

    @Autowired
    private IngredientRepository ingredientRepository;

    public List<Ingredient> getAll() {
        return ingredientRepository.getAll();
    }

    public int add(Ingredient ingredient) {
        return ingredientRepository.add(ingredient);
    }

    public boolean edit(Ingredient ingredient) {
        return ingredientRepository.edit(ingredient);
    }

    public boolean delete(int ingredientId) {
        return ingredientRepository.delete(ingredientId);
    }

}
