package pl.jukidesigner.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.jukidesigner.model.Category;
import pl.jukidesigner.repository.CategoryRepository;
import pl.jukidesigner.service.CategoryService;

import java.util.Collection;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAll() {
        return categoryRepository.getAll();
    }

    public int add(Category category) {
        return categoryRepository.add(category);
    }

    public boolean edit(Category category) {
        return categoryRepository.edit(category);
    }

    public boolean delete(int categoryId) {
        return categoryRepository.delete(categoryId);
    }

}
