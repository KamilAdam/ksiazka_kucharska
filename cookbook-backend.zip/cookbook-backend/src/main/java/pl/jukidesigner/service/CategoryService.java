package pl.jukidesigner.service;

import pl.jukidesigner.model.Category;

import java.util.Collection;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public interface CategoryService {

    public List<Category> getAll();
    public int add(Category category);
    public boolean edit(Category category);
    public boolean delete(int categoryId);

}
