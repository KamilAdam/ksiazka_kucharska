package pl.jukidesigner.service;

import pl.jukidesigner.model.Ingredient;

import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public interface IngredientService {

    public List<Ingredient> getAll();
    public int add(Ingredient ingredient);
    public boolean edit(Ingredient ingredient);
    public boolean delete(int ingredientId);

}
