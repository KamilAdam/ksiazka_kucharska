package pl.jukidesigner.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.jukidesigner.model.Comment;
import pl.jukidesigner.model.Recipe;
import pl.jukidesigner.repository.RecipeRepository;
import pl.jukidesigner.service.RecipeService;

import java.util.Date;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */

@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

    public List<Recipe> getAll() {
        return recipeRepository.getAll();
    }

    public int add(Recipe recipe) {
        return recipeRepository.add(recipe);
    }

    public boolean edit(Recipe recipe) {
        return recipeRepository.edit(recipe);
    }

    public boolean delete(int recipeId) {
        return recipeRepository.delete(recipeId);
    }

    public boolean toggleFavorite(int recipeId, boolean currentStatus) {
        return recipeRepository.toggleFavorite(recipeId, currentStatus);
    }

    public boolean updateComments(List<Comment> comments, int recipeId){
        return recipeRepository.updateComments(comments, recipeId);
    }

    public boolean updateLastCookDate(int recipeId, Date date){
        return recipeRepository.updateLastCookDate(recipeId, date);
    }
}