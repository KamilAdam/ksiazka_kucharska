package pl.jukidesigner.model;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public class Comment {

    private int id;
    private int recipeId;
    private String content;

    public Comment(){

    }

    public Comment(int id, int recipeId, String content) {
        this.id = id;
        this.recipeId = recipeId;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(int recipeId) {
        this.recipeId = recipeId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", recipeId=" + recipeId +
                ", content='" + content + '\'' +
                '}';
    }

}
