package pl.jukidesigner.model;

import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public class Ingredient {

    private int id;
    private String name;
    private List<String> units;

    public Ingredient(){

    }

    public Ingredient(int id, String name, List<String> units) {
        this.id = id;
        this.name = name;
        this.units = units;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getUnits() {
        return units;
    }

    public void setUnits(List<String> units) {
        this.units = units;
    }

}
