package pl.jukidesigner.model;

import java.util.Date;
import java.util.List;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public class Recipe {

    private int id;
    private String name;
    private String description;
    private List<Integer> categories;
    private List<Integer> ingredients;
    private List<IngredientValue> ingredientValues;
    private List<CustomIngredient> customIngredients;
    private List<Comment> comments;
    private int prepareTime;
    private int costsServing;
    private int calories;
    private int numberServing;
    private Date publishDate;
    private Date lastCookedDate;
    private boolean favorite;

    public Recipe(){

    }

    public Recipe(int id, String name, String description, List<Integer> categories, List<Integer> ingredients, List<IngredientValue> ingredientValues, List<CustomIngredient> customIngredients, List<Comment> comments, int prepareTime, int costsServing, int calories, int numberServing, Date publishDate, Date lastCookedDate, boolean favorite) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.categories = categories;
        this.ingredients = ingredients;
        this.ingredientValues = ingredientValues;
        this.customIngredients = customIngredients;
        this.comments = comments;
        this.prepareTime = prepareTime;
        this.costsServing = costsServing;
        this.calories = calories;
        this.numberServing = numberServing;
        this.publishDate = publishDate;
        this.lastCookedDate = lastCookedDate;
        this.favorite = favorite;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Integer> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Integer> ingredients) {
        this.ingredients = ingredients;
    }

    public List<IngredientValue> getIngredientValues() {
        return ingredientValues;
    }

    public void setIngredientValues(List<IngredientValue> ingredientValues) {
        this.ingredientValues = ingredientValues;
    }

    public List<CustomIngredient> getCustomIngredients() {
        return customIngredients;
    }

    public void setCustomIngredients(List<CustomIngredient> customIngredients) {
        this.customIngredients = customIngredients;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public int getPrepareTime() {
        return prepareTime;
    }

    public void setPrepareTime(int prepareTime) {
        this.prepareTime = prepareTime;
    }

    public int getCostsServing() {
        return costsServing;
    }

    public void setCostsServing(int costsServing) {
        this.costsServing = costsServing;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public int getNumberServing() {
        return numberServing;
    }

    public void setNumberServing(int numberServing) {
        this.numberServing = numberServing;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public Date getLastCookedDate() {
        return lastCookedDate;
    }

    public void setLastCookedDate(Date lastCookedDate) {
        this.lastCookedDate = lastCookedDate;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public List<Integer> getCategories() {
        return categories;
    }

    public void setCategories(List<Integer> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "Recipe{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", categories=" + categories +
                ", ingredients=" + ingredients +
                ", ingredientValues=" + ingredientValues +
                ", customIngredients=" + customIngredients +
                ", comments=" + comments +
                ", prepareTime=" + prepareTime +
                ", costsServing=" + costsServing +
                ", calories=" + calories +
                ", numberServing=" + numberServing +
                ", publishDate=" + publishDate +
                ", lastCookedDate=" + lastCookedDate +
                ", favorite=" + favorite +
                '}';
    }

}
