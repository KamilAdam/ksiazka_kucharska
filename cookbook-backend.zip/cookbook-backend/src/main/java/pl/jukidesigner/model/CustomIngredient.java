package pl.jukidesigner.model;

/**
 * Created by Piotr Stachurski on 18.01.2017.
 */
public class CustomIngredient {

    private String name;
    private String quantity;
    private String unit;

    public CustomIngredient(){

    }

    public CustomIngredient(String name, String quantity, String unit) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
    }

    public CustomIngredient(String name, int quantity, String unit) {
        this.name = name;
        this.quantity = Integer.toString(quantity);
        this.unit = unit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "{\"name\":"+"\""+name+"\",\"quantity\":"+"\""+quantity+"\",\"unit\":"+"\""+unit+"\"}";
    }

}
