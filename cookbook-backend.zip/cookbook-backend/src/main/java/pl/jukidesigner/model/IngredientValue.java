package pl.jukidesigner.model;

/**
 * Created by Piotr Stachurski on 19.01.2017.
 */
public class IngredientValue {

    private String quantity;
    private String unit;

    public IngredientValue(){

    }

    public IngredientValue(String quantity, String unit) {
        this.unit = unit;
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String name) {
        this.unit = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "IngredientValue{" +
                "unit='" + unit + '\'' +
                ", quantity='" + quantity + '\'' +
                '}';
    }

}
